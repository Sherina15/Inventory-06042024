package InventoryAndSchedulingSystem;

import java.awt.Color;
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.ResultSet;
//import java.sql.Statement;
//import java.sql.PreparedStatement;
//import java.sql.SQLException;
//import java.util.logging.Level;
//import java.util.logging.Logger;

public class Login extends javax.swing.JFrame {

    public Login() {
        initComponents();
        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        right_Panel = new javax.swing.JPanel();
        left_Panel = new javax.swing.JPanel();
        login_Label = new javax.swing.JLabel();
        greetings_Label = new javax.swing.JLabel();
        username_Label = new javax.swing.JLabel();
        profile_Icon = new javax.swing.JLabel();
        line1_Label = new javax.swing.JLabel();
        username_TextField = new javax.swing.JTextField();
        password_Label = new javax.swing.JLabel();
        lock_Icon = new javax.swing.JLabel();
        line2_Label = new javax.swing.JLabel();
        password_Field = new javax.swing.JPasswordField();
        show_Icon = new javax.swing.JLabel();
        login_Button = new javax.swing.JButton();
        signup_Label_Button = new javax.swing.JLabel();
        hide_Icon = new javax.swing.JLabel();
        signUp_Label_Button = new javax.swing.JLabel();
        clientShop_Logo = new javax.swing.JLabel();
        clientShop_Name = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("LOGIN");

        right_Panel.setBackground(new java.awt.Color(0, 0, 0));
        right_Panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        left_Panel.setBackground(new java.awt.Color(255, 255, 255));
        left_Panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        login_Label.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        login_Label.setText("LOGIN");
        login_Label.setToolTipText("");
        left_Panel.add(login_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(122, 19, -1, -1));

        greetings_Label.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        greetings_Label.setText("HEY, WELCOME");
        left_Panel.add(greetings_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(32, 101, -1, -1));

        username_Label.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        username_Label.setText("Username");
        left_Panel.add(username_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(32, 160, -1, -1));

        profile_Icon.setForeground(new java.awt.Color(255, 255, 255));
        profile_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_user.png"))); // NOI18N
        left_Panel.add(profile_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(41, 205, 24, -1));

        line1_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        line1_Label.setText("____________________________________________");
        left_Panel.add(line1_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(71, 197, 272, 48));

        username_TextField.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        username_TextField.setForeground(new java.awt.Color(153, 153, 153));
        username_TextField.setText("Enter Username");
        username_TextField.setBorder(null);
        username_TextField.setDragEnabled(true);
        username_TextField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                username_TextFieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                username_TextFieldFocusLost(evt);
            }
        });
        left_Panel.add(username_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(71, 197, 260, 30));

        password_Label.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        password_Label.setText("Password");
        left_Panel.add(password_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(32, 269, -1, -1));

        lock_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_lock.png"))); // NOI18N
        lock_Icon.setToolTipText("");
        left_Panel.add(lock_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(44, 314, -1, -1));

        line2_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        line2_Label.setText("____________________________________________");
        left_Panel.add(line2_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(72, 306, 278, 48));

        password_Field.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        password_Field.setForeground(new java.awt.Color(153, 153, 153));
        password_Field.setText("Enter Password");
        password_Field.setBorder(null);
        password_Field.setDragEnabled(true);
        password_Field.setEchoChar('\u0000');
        password_Field.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                password_FieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                password_FieldFocusLost(evt);
            }
        });
        left_Panel.add(password_Field, new org.netbeans.lib.awtextra.AbsoluteConstraints(72, 306, 260, 30));

        show_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_eyes.png"))); // NOI18N
        show_Icon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                show_IconMousePressed(evt);
            }
        });
        left_Panel.add(show_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 310, 30, 30));

        login_Button.setBackground(new java.awt.Color(0, 0, 0));
        login_Button.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        login_Button.setForeground(new java.awt.Color(255, 255, 255));
        login_Button.setText("LOGIN");
        login_Button.setToolTipText("click Login");
        login_Button.setBorder(null);
        login_Button.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        login_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                login_ButtonActionPerformed(evt);
            }
        });
        left_Panel.add(login_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 360, 305, 40));

        signup_Label_Button.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        signup_Label_Button.setText("Don't have an account? ");
        signup_Label_Button.setToolTipText("Click to create account");
        signup_Label_Button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                signup_Label_ButtonMouseClicked(evt);
            }
        });
        left_Panel.add(signup_Label_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 420, -1, -1));

        hide_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_hideeye.png"))); // NOI18N
        hide_Icon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                hide_IconMousePressed(evt);
            }
        });
        left_Panel.add(hide_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 310, 30, 30));

        signUp_Label_Button.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        signUp_Label_Button.setForeground(new java.awt.Color(102, 0, 0));
        signUp_Label_Button.setText("Sign Up");
        signUp_Label_Button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                signUp_Label_ButtonMouseClicked(evt);
            }
        });
        left_Panel.add(signUp_Label_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 410, 80, 40));

        right_Panel.add(left_Panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 410, 540));

        clientShop_Logo.setForeground(new java.awt.Color(255, 255, 255));
        clientShop_Logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/client_logo.png"))); // NOI18N
        right_Panel.add(clientShop_Logo, new org.netbeans.lib.awtextra.AbsoluteConstraints(456, 26, -1, -1));

        clientShop_Name.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        clientShop_Name.setForeground(new java.awt.Color(255, 255, 255));
        clientShop_Name.setText("DeTails Pet Essentials and Lodging");
        right_Panel.add(clientShop_Name, new org.netbeans.lib.awtextra.AbsoluteConstraints(456, 332, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(right_Panel, javax.swing.GroupLayout.DEFAULT_SIZE, 800, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(right_Panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void signup_Label_ButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_signup_Label_ButtonMouseClicked
        Registration registrationModule = new Registration();
        registrationModule.setVisible(true);
        dispose();      
    }//GEN-LAST:event_signup_Label_ButtonMouseClicked

    private void show_IconMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_show_IconMousePressed
        show_Icon.setVisible(false);
        hide_Icon.setVisible(true);
        
        password_Field.setEchoChar ((char)0);       
    }//GEN-LAST:event_show_IconMousePressed

    private void hide_IconMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_hide_IconMousePressed
        show_Icon.setVisible(true);
        hide_Icon.setVisible(false);
        
        password_Field.setEchoChar ('•');
    }//GEN-LAST:event_hide_IconMousePressed

    private void username_TextFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_username_TextFieldFocusGained
        if (username_TextField.getText().equals("Enter Username"))
        {
            username_TextField.setText("");
            username_TextField.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_username_TextFieldFocusGained

    private void username_TextFieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_username_TextFieldFocusLost
        if (username_TextField.getText().equals(""))
        {
            username_TextField.setText("Enter Username");
            username_TextField.setForeground(new java.awt.Color(153,153,153));
        }
    }//GEN-LAST:event_username_TextFieldFocusLost

    private void login_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_login_ButtonActionPerformed
        Menu menuSystemModule = new Menu();
        menuSystemModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_login_ButtonActionPerformed

    private void password_FieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_password_FieldFocusGained
        if (String.valueOf(password_Field.getPassword()).equals("Enter Password"))
        {
           password_Field.setText("");
           password_Field.setForeground(Color.BLACK);
           password_Field.setEchoChar('•');
        }
    }//GEN-LAST:event_password_FieldFocusGained

    private void password_FieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_password_FieldFocusLost
        if (password_Field.getPassword().length<1)
        {
            password_Field.setEchoChar('\u0000');
            password_Field.setText("Enter Password");
            password_Field.setForeground(new java.awt.Color(153,153,153));
        }
    }//GEN-LAST:event_password_FieldFocusLost

    private void signUp_Label_ButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_signUp_Label_ButtonMouseClicked
        Registration registrationModule = new Registration();
        registrationModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_signUp_Label_ButtonMouseClicked


    public static void main(String args[]) {
 
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel clientShop_Logo;
    private javax.swing.JLabel clientShop_Name;
    private javax.swing.JLabel greetings_Label;
    private javax.swing.JLabel hide_Icon;
    private javax.swing.JPanel left_Panel;
    private javax.swing.JLabel line1_Label;
    private javax.swing.JLabel line2_Label;
    private javax.swing.JLabel lock_Icon;
    private javax.swing.JButton login_Button;
    private javax.swing.JLabel login_Label;
    private javax.swing.JPasswordField password_Field;
    private javax.swing.JLabel password_Label;
    private javax.swing.JLabel profile_Icon;
    private javax.swing.JPanel right_Panel;
    private javax.swing.JLabel show_Icon;
    private javax.swing.JLabel signUp_Label_Button;
    private javax.swing.JLabel signup_Label_Button;
    private javax.swing.JLabel username_Label;
    private javax.swing.JTextField username_TextField;
    // End of variables declaration//GEN-END:variables
}
