package InventoryAndSchedulingSystem;

public class EditAccount extends javax.swing.JFrame {


    public EditAccount() {
        initComponents();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        whole_Panel = new javax.swing.JPanel();
        top_Panel = new javax.swing.JPanel();
        editAccount_Label = new javax.swing.JLabel();
        back_Button = new javax.swing.JButton();
        clientShop_Logo = new javax.swing.JLabel();
        editAccount_ScrollPane = new javax.swing.JScrollPane();
        editAccount_Table = new javax.swing.JTable();
        accountNumber_Label = new javax.swing.JLabel();
        accountNumber_TextField = new javax.swing.JTextField();
        email_Label = new javax.swing.JLabel();
        email_TextField = new javax.swing.JTextField();
        username_Label = new javax.swing.JLabel();
        username_TextField = new javax.swing.JTextField();
        password_Label = new javax.swing.JLabel();
        password_Field = new javax.swing.JPasswordField();
        showPassword_CheckBox = new javax.swing.JCheckBox();
        phoneNumber_Label = new javax.swing.JLabel();
        phoneNumber_TextField = new javax.swing.JTextField();
        save_Button = new javax.swing.JButton();
        logout_Icon = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("EDIT ACCOUNT");

        whole_Panel.setBackground(new java.awt.Color(255, 255, 255));
        whole_Panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        top_Panel.setBackground(new java.awt.Color(0, 0, 0));

        editAccount_Label.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        editAccount_Label.setForeground(new java.awt.Color(255, 255, 255));
        editAccount_Label.setText("EDIT ACCOUNT");

        back_Button.setText("Back");
        back_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                back_ButtonActionPerformed(evt);
            }
        });

        clientShop_Logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/1x1_logo.png"))); // NOI18N

        javax.swing.GroupLayout top_PanelLayout = new javax.swing.GroupLayout(top_Panel);
        top_Panel.setLayout(top_PanelLayout);
        top_PanelLayout.setHorizontalGroup(
            top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(top_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(back_Button)
                    .addComponent(editAccount_Label))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 364, Short.MAX_VALUE)
                .addComponent(clientShop_Logo, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        top_PanelLayout.setVerticalGroup(
            top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(top_PanelLayout.createSequentialGroup()
                .addGap(7, 7, 7)
                .addGroup(top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(top_PanelLayout.createSequentialGroup()
                        .addComponent(clientShop_Logo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(top_PanelLayout.createSequentialGroup()
                        .addComponent(back_Button)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(editAccount_Label, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        whole_Panel.add(top_Panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 810, 100));

        editAccount_Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Account No.", "Email", "Username", "Password", "Phone Number"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        editAccount_Table.getTableHeader().setReorderingAllowed(false);
        editAccount_ScrollPane.setViewportView(editAccount_Table);
        if (editAccount_Table.getColumnModel().getColumnCount() > 0) {
            editAccount_Table.getColumnModel().getColumn(0).setResizable(false);
            editAccount_Table.getColumnModel().getColumn(1).setResizable(false);
            editAccount_Table.getColumnModel().getColumn(2).setResizable(false);
            editAccount_Table.getColumnModel().getColumn(3).setResizable(false);
            editAccount_Table.getColumnModel().getColumn(4).setResizable(false);
        }

        whole_Panel.add(editAccount_ScrollPane, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, 520, 370));

        accountNumber_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        accountNumber_Label.setText("Account Number");
        whole_Panel.add(accountNumber_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 110, -1, -1));
        whole_Panel.add(accountNumber_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 140, 200, 35));

        email_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        email_Label.setText("Email");
        whole_Panel.add(email_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 180, -1, -1));
        whole_Panel.add(email_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 210, 200, 35));

        username_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        username_Label.setText("Username");
        whole_Panel.add(username_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 250, -1, -1));
        whole_Panel.add(username_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 280, 200, 35));

        password_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        password_Label.setText("Password");
        whole_Panel.add(password_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 320, -1, -1));
        whole_Panel.add(password_Field, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 350, 200, 35));

        showPassword_CheckBox.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        showPassword_CheckBox.setText("Show Password");
        whole_Panel.add(showPassword_CheckBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 390, -1, -1));

        phoneNumber_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        phoneNumber_Label.setText("Phone Number");
        whole_Panel.add(phoneNumber_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 410, -1, -1));
        whole_Panel.add(phoneNumber_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 440, 200, 35));

        save_Button.setText("Save");
        save_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                save_ButtonActionPerformed(evt);
            }
        });
        whole_Panel.add(save_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 490, -1, -1));

        logout_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_exit.png"))); // NOI18N
        logout_Icon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logout_IconMouseClicked(evt);
            }
        });
        whole_Panel.add(logout_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 490, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, 540, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void back_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_back_ButtonActionPerformed
        ViewAdminAccount viewAdminAccountModule = new ViewAdminAccount();
        viewAdminAccountModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_back_ButtonActionPerformed

    private void logout_IconMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logout_IconMouseClicked
       Login LoginModule = new Login();
       LoginModule.setVisible(true);
       dispose();
    }//GEN-LAST:event_logout_IconMouseClicked

    private void save_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_save_ButtonActionPerformed
        ViewAdminAccount viewAdminAccountModule = new ViewAdminAccount();
        viewAdminAccountModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_save_ButtonActionPerformed


    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EditAccount().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel accountNumber_Label;
    private javax.swing.JTextField accountNumber_TextField;
    private javax.swing.JButton back_Button;
    private javax.swing.JLabel clientShop_Logo;
    private javax.swing.JLabel editAccount_Label;
    private javax.swing.JScrollPane editAccount_ScrollPane;
    private javax.swing.JTable editAccount_Table;
    private javax.swing.JLabel email_Label;
    private javax.swing.JTextField email_TextField;
    private javax.swing.JLabel logout_Icon;
    private javax.swing.JPasswordField password_Field;
    private javax.swing.JLabel password_Label;
    private javax.swing.JLabel phoneNumber_Label;
    private javax.swing.JTextField phoneNumber_TextField;
    private javax.swing.JButton save_Button;
    private javax.swing.JCheckBox showPassword_CheckBox;
    private javax.swing.JPanel top_Panel;
    private javax.swing.JLabel username_Label;
    private javax.swing.JTextField username_TextField;
    private javax.swing.JPanel whole_Panel;
    // End of variables declaration//GEN-END:variables
}
