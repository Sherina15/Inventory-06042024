package InventoryAndSchedulingSystem;


public class UpdateSchedule extends javax.swing.JFrame {

    public UpdateSchedule() {
        initComponents();
    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        whole_Panel = new javax.swing.JPanel();
        top_Panel = new javax.swing.JPanel();
        back_Button = new javax.swing.JButton();
        updateSchedule_Label = new javax.swing.JLabel();
        clientShop_Logo = new javax.swing.JLabel();
        reservationNo_Label = new javax.swing.JLabel();
        reservatioNo_TextField = new javax.swing.JTextField();
        petName_Label = new javax.swing.JLabel();
        petName_TextField = new javax.swing.JTextField();
        ownerName_Label = new javax.swing.JLabel();
        ownerName_TextField = new javax.swing.JTextField();
        phoneNumber_Label = new javax.swing.JLabel();
        phoneNumber_TextField = new javax.swing.JTextField();
        petSize_Label = new javax.swing.JLabel();
        petSize_ComboBox = new javax.swing.JComboBox<>();
        serviceType_Label = new javax.swing.JLabel();
        serviceType_ComboBox = new javax.swing.JComboBox<>();
        date_Label = new javax.swing.JLabel();
        date_Picker = new com.github.lgooddatepicker.components.DatePicker();
        time_Label = new javax.swing.JLabel();
        time_ComboBox = new javax.swing.JComboBox<>();
        price_Label = new javax.swing.JLabel();
        price_TextField = new javax.swing.JTextField();
        update_Button = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("UPDATE SCHEDULE");

        whole_Panel.setBackground(new java.awt.Color(255, 255, 255));
        whole_Panel.setPreferredSize(new java.awt.Dimension(400, 600));

        top_Panel.setBackground(new java.awt.Color(0, 0, 0));

        back_Button.setText("Back");
        back_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                back_ButtonActionPerformed(evt);
            }
        });

        updateSchedule_Label.setText("Update Schedule");
        updateSchedule_Label.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        updateSchedule_Label.setForeground(new java.awt.Color(255, 255, 255));

        clientShop_Logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/1x1_logo.png"))); // NOI18N

        javax.swing.GroupLayout top_PanelLayout = new javax.swing.GroupLayout(top_Panel);
        top_Panel.setLayout(top_PanelLayout);
        top_PanelLayout.setHorizontalGroup(
            top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, top_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(back_Button)
                    .addComponent(updateSchedule_Label))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 33, Short.MAX_VALUE)
                .addComponent(clientShop_Logo)
                .addContainerGap())
        );
        top_PanelLayout.setVerticalGroup(
            top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(top_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(clientShop_Logo)
                    .addGroup(top_PanelLayout.createSequentialGroup()
                        .addComponent(back_Button)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(updateSchedule_Label)))
                .addContainerGap(10, Short.MAX_VALUE))
        );

        reservationNo_Label.setText("Reservation No.");
        reservationNo_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N

        petName_Label.setText("Pet's Name");
        petName_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N

        ownerName_Label.setText("Owner's Name");
        ownerName_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N

        phoneNumber_Label.setText("Contact Number");
        phoneNumber_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N

        petSize_Label.setText("Pet's Size ");
        petSize_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N

        petSize_ComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        serviceType_Label.setText("Service Type");
        serviceType_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N

        serviceType_ComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        date_Label.setText("Date");
        date_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N

        time_Label.setText("Time");
        time_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N

        time_ComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        price_Label.setText("Price");
        price_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N

        update_Button.setText("Update");
        update_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_ButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout whole_PanelLayout = new javax.swing.GroupLayout(whole_Panel);
        whole_Panel.setLayout(whole_PanelLayout);
        whole_PanelLayout.setHorizontalGroup(
            whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(whole_PanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, whole_PanelLayout.createSequentialGroup()
                            .addGroup(whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(petName_Label)
                                .addComponent(ownerName_Label)
                                .addComponent(phoneNumber_Label)
                                .addComponent(petSize_Label)
                                .addComponent(serviceType_Label)
                                .addComponent(date_Label))
                            .addGap(70, 70, 70))
                        .addGroup(whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(price_Label, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(time_ComboBox, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(serviceType_ComboBox, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(petSize_ComboBox, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(phoneNumber_TextField, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ownerName_TextField, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(petName_TextField, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(reservatioNo_TextField, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(date_Picker, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(time_Label)
                    .addComponent(reservationNo_Label)
                    .addGroup(whole_PanelLayout.createSequentialGroup()
                        .addComponent(price_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(update_Button)))
                .addGap(32, 32, 32))
            .addGroup(whole_PanelLayout.createSequentialGroup()
                .addComponent(top_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        whole_PanelLayout.setVerticalGroup(
            whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(whole_PanelLayout.createSequentialGroup()
                .addComponent(top_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(whole_PanelLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(reservationNo_Label)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(reservatioNo_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(petName_Label)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(petName_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ownerName_Label)
                        .addGap(3, 3, 3)
                        .addComponent(ownerName_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(phoneNumber_Label)
                        .addGap(2, 2, 2)
                        .addComponent(phoneNumber_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(petSize_Label)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(petSize_ComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(serviceType_Label)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(serviceType_ComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(date_Label)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(date_Picker, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(3, 3, 3)
                        .addComponent(time_Label)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(time_ComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(price_Label)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(price_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(26, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, whole_PanelLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(update_Button)
                        .addContainerGap())))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void back_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_back_ButtonActionPerformed
        EditSchedule editScheduleModule = new EditSchedule();
        editScheduleModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_back_ButtonActionPerformed

    private void update_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_ButtonActionPerformed
       ViewSchedule ViewScheduleModule = new ViewSchedule();
       ViewScheduleModule.setVisible(true);
       dispose();
    }//GEN-LAST:event_update_ButtonActionPerformed


    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UpdateSchedule().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton back_Button;
    private javax.swing.JLabel clientShop_Logo;
    private javax.swing.JLabel date_Label;
    private com.github.lgooddatepicker.components.DatePicker date_Picker;
    private javax.swing.JLabel ownerName_Label;
    private javax.swing.JTextField ownerName_TextField;
    private javax.swing.JLabel petName_Label;
    private javax.swing.JTextField petName_TextField;
    private javax.swing.JComboBox<String> petSize_ComboBox;
    private javax.swing.JLabel petSize_Label;
    private javax.swing.JLabel phoneNumber_Label;
    private javax.swing.JTextField phoneNumber_TextField;
    private javax.swing.JLabel price_Label;
    private javax.swing.JTextField price_TextField;
    private javax.swing.JTextField reservatioNo_TextField;
    private javax.swing.JLabel reservationNo_Label;
    private javax.swing.JComboBox<String> serviceType_ComboBox;
    private javax.swing.JLabel serviceType_Label;
    private javax.swing.JComboBox<String> time_ComboBox;
    private javax.swing.JLabel time_Label;
    private javax.swing.JPanel top_Panel;
    private javax.swing.JLabel updateSchedule_Label;
    private javax.swing.JButton update_Button;
    private javax.swing.JPanel whole_Panel;
    // End of variables declaration//GEN-END:variables
}
